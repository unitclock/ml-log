#数据储存类
class DataManager():
    def __init__()->None:
        pass
