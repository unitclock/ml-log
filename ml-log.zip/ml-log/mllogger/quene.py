#消息管理基类
class Quene():
    def __init__(self):
        pass
    def Insert()->None:
        pass