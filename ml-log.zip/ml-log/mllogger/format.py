#格式化静态方法类
class Formater():
    def __init__(self)->None:
        pass 
    