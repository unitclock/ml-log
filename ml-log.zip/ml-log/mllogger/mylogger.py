from utils import single

@single
class Logger():
    def __init__(self)->None:
        pass
    def Start(self)->None:
        pass
    def Run(self)->None:
        pass
    def End(self)->None:
        pass
    def Submit(self)->None:
        pass



    

