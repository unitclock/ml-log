class Clinet():
    def __init__(self)->None:
        pass
    def ShakeHand(self)->None:
        pass
    def NoticeExpStart(self)->None:
        pass
    def NoticeRunStart(self)->None:
        pass
    def NoticeRunStop(self)->None:
        pass
    def NoticeExpStop(self)->None:
        pass
